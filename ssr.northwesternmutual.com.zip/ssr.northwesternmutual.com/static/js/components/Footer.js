
import React from 'react';

export default function Footer() {
    return (
        <footer className="App-footer">
            <p className="luna-type-body-20">Copyright &copy; {(new Date()).getFullYear()} The Northwestern Mutual Life Insurance Company, Northwestern Mutual Investment Services, LLC, Northwestern Mutual Wealth Management Company and Northwestern Long Term Care Insurance Company. All Rights Reserved.</p>
        </footer>
    )
}